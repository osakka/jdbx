#include "binary/binary_format.h"
#include "binary/binary_transactions.h"
#include "database/database.h"
#include "utils/logger.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>

/**
 * Binary transaction log implementation
 * 
 * This file provides binary serialization for transaction logs,
 * significantly improving performance for high-throughput systems.
 */

/* Binary transaction log entry header */
typedef struct {
    uint32_t magic;              /* Magic number (JSTX) */
    uint64_t timestamp;          /* Timestamp of the transaction */
    uint32_t operation_type;     /* Type of operation */
    uint32_t transaction_id;     /* Transaction ID */
    uint32_t collection_name_len; /* Length of collection name */
    uint32_t document_id_len;    /* Length of document ID */
    uint64_t document_size;      /* Size of document data */
    uint32_t checksum;           /* Header checksum */
} __attribute__((packed)) binary_transaction_header_t;

/* Global transaction log file handle */
static int g_transaction_log_fd = -1;
static pthread_mutex_t g_transaction_log_mutex = PTHREAD_MUTEX_INITIALIZER;

/**
 * Initialize binary transaction log
 * 
 * @param path Path to the transaction log file
 * @return 1 on success, 0 on failure
 */
int binary_transaction_log_init(const char* path) {
    if (!path) {
        LOG_ERROR("Invalid transaction log path");
        return 0;
    }
    
    pthread_mutex_lock(&g_transaction_log_mutex);
    
    /* Close existing file if open */
    if (g_transaction_log_fd >= 0) {
        close(g_transaction_log_fd);
        g_transaction_log_fd = -1;
    }
    
    /* Open transaction log file */
    g_transaction_log_fd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (g_transaction_log_fd < 0) {
        LOG_ERROR("Failed to open transaction log file: %s (error: %s)",
                 path, strerror(errno));
        pthread_mutex_unlock(&g_transaction_log_mutex);
        return 0;
    }
    
    LOG_INFO("Initialized binary transaction log: %s", path);
    
    pthread_mutex_unlock(&g_transaction_log_mutex);
    return 1;
}

/**
 * Close binary transaction log
 */
void binary_transaction_log_close() {
    pthread_mutex_lock(&g_transaction_log_mutex);
    
    if (g_transaction_log_fd >= 0) {
        close(g_transaction_log_fd);
        g_transaction_log_fd = -1;
    }
    
    pthread_mutex_unlock(&g_transaction_log_mutex);
}

/**
 * Log a transaction operation
 * 
 * @param transaction_id Transaction ID
 * @param op_type Operation type
 * @param collection Collection name
 * @param document_id Document ID
 * @param document Document data
 * @return 1 on success, 0 on failure
 */
int binary_transaction_log_operation(uint32_t transaction_id, 
                                   binary_transaction_op_type_t op_type,
                                   const char* collection, const char* document_id,
                                   json_value_t* document) {
    if (g_transaction_log_fd < 0) {
        LOG_ERROR("Transaction log not initialized");
        return 0;
    }
    
    if (!collection) {
        LOG_ERROR("Invalid collection name");
        return 0;
    }
    
    /* For operations that require document ID */
    if ((op_type == BINARY_TRANS_OP_UPDATE || op_type == BINARY_TRANS_OP_DELETE) && !document_id) {
        LOG_ERROR("Document ID required for update/delete operations");
        return 0;
    }
    
    /* For operations that require document data */
    if ((op_type == BINARY_TRANS_OP_INSERT || op_type == BINARY_TRANS_OP_UPDATE) && !document) {
        LOG_ERROR("Document data required for insert/update operations");
        return 0;
    }
    
    pthread_mutex_lock(&g_transaction_log_mutex);
    
    /* Prepare transaction header */
    binary_transaction_header_t header;
    memset(&header, 0, sizeof(header));
    
    header.magic = 0x4A535458; /* "JSTX" */
    header.timestamp = (uint64_t)time(NULL);
    header.operation_type = op_type;
    header.transaction_id = transaction_id;
    header.collection_name_len = collection ? (uint32_t)strlen(collection) : 0;
    header.document_id_len = document_id ? (uint32_t)strlen(document_id) : 0;
    
    /* Calculate document size if present */
    char* document_str = NULL;
    if (document) {
        document_str = json_stringify(document);
        if (document_str) {
            header.document_size = strlen(document_str);
        }
    }
    
    /* Calculate checksum */
    header.checksum = binary_calculate_checksum(&header, sizeof(header) - sizeof(uint32_t));
    
    /* Write header */
    if (write(g_transaction_log_fd, &header, sizeof(header)) != sizeof(header)) {
        LOG_ERROR("Failed to write transaction header: %s", strerror(errno));
        free(document_str);
        pthread_mutex_unlock(&g_transaction_log_mutex);
        return 0;
    }
    
    /* Write collection name */
    if (header.collection_name_len > 0) {
        if (write(g_transaction_log_fd, collection, header.collection_name_len) != 
               (ssize_t)header.collection_name_len) {
            LOG_ERROR("Failed to write collection name: %s", strerror(errno));
            free(document_str);
            pthread_mutex_unlock(&g_transaction_log_mutex);
            return 0;
        }
    }
    
    /* Write document ID */
    if (header.document_id_len > 0) {
        if (write(g_transaction_log_fd, document_id, header.document_id_len) != 
               (ssize_t)header.document_id_len) {
            LOG_ERROR("Failed to write document ID: %s", strerror(errno));
            free(document_str);
            pthread_mutex_unlock(&g_transaction_log_mutex);
            return 0;
        }
    }
    
    /* Write document data */
    if (document_str && header.document_size > 0) {
        if (write(g_transaction_log_fd, document_str, header.document_size) != 
               (ssize_t)header.document_size) {
            LOG_ERROR("Failed to write document data: %s", strerror(errno));
            free(document_str);
            pthread_mutex_unlock(&g_transaction_log_mutex);
            return 0;
        }
    }
    
    /* Ensure data is written to disk */
    fsync(g_transaction_log_fd);
    
    free(document_str);
    pthread_mutex_unlock(&g_transaction_log_mutex);
    return 1;
}

/**
 * Log a simple transaction event (begin/commit/rollback)
 * 
 * @param transaction_id Transaction ID
 * @param op_type Operation type
 * @return 1 on success, 0 on failure
 */
int binary_transaction_log_event(uint32_t transaction_id, binary_transaction_op_type_t op_type) {
    if (op_type != BINARY_TRANS_OP_BEGIN && op_type != BINARY_TRANS_OP_COMMIT && op_type != BINARY_TRANS_OP_ROLLBACK) {
        LOG_ERROR("Invalid operation type for transaction event");
        return 0;
    }
    
    return binary_transaction_log_operation(transaction_id, op_type, "", NULL, NULL);
}

/**
 * Read transaction log entry
 * 
 * @param fd File descriptor of the transaction log
 * @param header Header structure to fill
 * @param collection_name Buffer to store collection name
 * @param document_id Buffer to store document ID
 * @param document Buffer to store document data
 * @return 1 on success, 0 on failure or end of file
 */
static int read_transaction_log_entry(int fd, binary_transaction_header_t* header,
                                    char** collection_name, char** document_id,
                                    char** document_data) {
    /* Read header */
    ssize_t bytes_read = read(fd, header, sizeof(*header));
    if (bytes_read == 0) {
        /* End of file */
        return 0;
    }
    
    if (bytes_read != sizeof(*header)) {
        LOG_ERROR("Failed to read transaction header: %s", strerror(errno));
        return 0;
    }
    
    /* Verify magic number */
    if (header->magic != 0x4A535458) {
        LOG_ERROR("Invalid transaction header magic: 0x%08X", header->magic);
        return 0;
    }
    
    /* Verify checksum */
    uint32_t calculated_checksum = binary_calculate_checksum(header, 
                                    sizeof(*header) - sizeof(uint32_t));
    
    if (calculated_checksum != header->checksum) {
        LOG_ERROR("Transaction header checksum mismatch");
        return 0;
    }
    
    /* Read collection name */
    if (header->collection_name_len > 0) {
        *collection_name = (char*)malloc(header->collection_name_len + 1);
        if (!*collection_name) {
            LOG_ERROR("Failed to allocate memory for collection name");
            return 0;
        }
        
        if (read(fd, *collection_name, header->collection_name_len) != 
              (ssize_t)header->collection_name_len) {
            LOG_ERROR("Failed to read collection name: %s", strerror(errno));
            free(*collection_name);
            *collection_name = NULL;
            return 0;
        }
        
        (*collection_name)[header->collection_name_len] = '\0';
    } else {
        *collection_name = NULL;
    }
    
    /* Read document ID */
    if (header->document_id_len > 0) {
        *document_id = (char*)malloc(header->document_id_len + 1);
        if (!*document_id) {
            LOG_ERROR("Failed to allocate memory for document ID");
            free(*collection_name);
            *collection_name = NULL;
            return 0;
        }
        
        if (read(fd, *document_id, header->document_id_len) != 
              (ssize_t)header->document_id_len) {
            LOG_ERROR("Failed to read document ID: %s", strerror(errno));
            free(*collection_name);
            *collection_name = NULL;
            free(*document_id);
            *document_id = NULL;
            return 0;
        }
        
        (*document_id)[header->document_id_len] = '\0';
    } else {
        *document_id = NULL;
    }
    
    /* Read document data */
    if (header->document_size > 0) {
        *document_data = (char*)malloc(header->document_size + 1);
        if (!*document_data) {
            LOG_ERROR("Failed to allocate memory for document data");
            free(*collection_name);
            *collection_name = NULL;
            free(*document_id);
            *document_id = NULL;
            return 0;
        }
        
        if (read(fd, *document_data, header->document_size) != 
              (ssize_t)header->document_size) {
            LOG_ERROR("Failed to read document data: %s", strerror(errno));
            free(*collection_name);
            *collection_name = NULL;
            free(*document_id);
            *document_id = NULL;
            free(*document_data);
            *document_data = NULL;
            return 0;
        }
        
        (*document_data)[header->document_size] = '\0';
    } else {
        *document_data = NULL;
    }
    
    return 1;
}

/**
 * Replay transaction log
 * 
 * @param path Path to the transaction log file
 * @param db Database to apply transactions to
 * @return 1 on success, 0 on failure
 */
int binary_transaction_log_replay(const char* path, database_t* db) {
    if (!path || !db) {
        LOG_ERROR("Invalid parameters for transaction log replay");
        return 0;
    }
    
    /* Open transaction log file */
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        LOG_ERROR("Failed to open transaction log file: %s (error: %s)",
                 path, strerror(errno));
        return 0;
    }
    
    LOG_INFO("Replaying binary transaction log: %s", path);
    
    binary_transaction_header_t header;
    char* collection_name;
    char* document_id;
    char* document_data;
    
    /* Track active transactions */
    int active_transactions = 0;
    int total_operations = 0;
    
    /* Read and apply transactions */
    while (read_transaction_log_entry(fd, &header, &collection_name, &document_id, &document_data)) {
        switch (header.operation_type) {
            case BINARY_TRANS_OP_BEGIN:
                LOG_DEBUG("Transaction BEGIN: %u", header.transaction_id);
                active_transactions++;
                break;
                
            case BINARY_TRANS_OP_COMMIT:
                LOG_DEBUG("Transaction COMMIT: %u", header.transaction_id);
                active_transactions--;
                break;
                
            case BINARY_TRANS_OP_ROLLBACK:
                LOG_DEBUG("Transaction ROLLBACK: %u", header.transaction_id);
                active_transactions--;
                /* Skip operations in this transaction */
                /* In a real implementation, we would track operations by transaction ID */
                break;
                
            case BINARY_TRANS_OP_INSERT:
                if (collection_name && document_data) {
                    LOG_DEBUG("Transaction INSERT: %u, Collection: %s", 
                             header.transaction_id, collection_name);
                    
                    /* Parse document */
                    json_value_t* document = json_parse(document_data);
                    if (document) {
                        /* Create collection if it doesn't exist */
                        db_create_collection(db, collection_name);
                        
                        /* Insert document */
                        db_insert_document(db, collection_name, document);
                        
                        json_free(document);
                        total_operations++;
                    }
                }
                break;
                
            case BINARY_TRANS_OP_UPDATE:
                if (collection_name && document_id && document_data) {
                    LOG_DEBUG("Transaction UPDATE: %u, Collection: %s, ID: %s", 
                             header.transaction_id, collection_name, document_id);
                    
                    /* Parse document */
                    json_value_t* document = json_parse(document_data);
                    if (document) {
                        /* Update document */
                        db_update_document(db, collection_name, document_id, document);
                        
                        json_free(document);
                        total_operations++;
                    }
                }
                break;
                
            case BINARY_TRANS_OP_DELETE:
                if (collection_name && document_id) {
                    LOG_DEBUG("Transaction DELETE: %u, Collection: %s, ID: %s", 
                             header.transaction_id, collection_name, document_id);
                    
                    /* Delete document */
                    db_delete_document(db, collection_name, document_id);
                    
                    total_operations++;
                }
                break;
                
            default:
                LOG_WARNING("Unknown transaction operation type: %u", header.operation_type);
                break;
        }
        
        /* Free allocated strings */
        free(collection_name);
        free(document_id);
        free(document_data);
    }
    
    /* Close transaction log file */
    close(fd);
    
    LOG_INFO("Transaction log replay completed: %d operations processed, %d active transactions",
             total_operations, active_transactions);
    
    return 1;
}

/**
 * Initialize binary transaction operations
 */
void binary_transaction_init() {
    LOG_INFO("Initializing binary transaction operations");
    /* Any initialization can be done here */
}